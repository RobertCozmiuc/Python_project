<?php
/**
 * Simple Inventory API
 * @version 1.0.0
 */

require_once __DIR__ . '/vendor/autoload.php';

$app = new Slim\App();


/**
 * GET getCredentials
 * Summary: returneaza numele si parola
 * Notes: 

 */
$app->GET('/BideniaAlexandru/Prop/1.0.0/users/{Name}/{Pass}', function($request, $response, $args) {
            
            
            
            
            $response->write('How about implementing getCredentials as a GET method ?');
            return $response;
            });


/**
 * POST postRecipePost
 * Summary: Adauga o retena noua
 * Notes: 

 */
$app->POST('/BideniaAlexandru/Prop/1.0.0/Post_Recipe', function($request, $response, $args) {
            
            
            
            $body = $request->getParsedBody();
            $response->write('How about implementing postRecipePost as a POST method ?');
            return $response;
            });


/**
 * POST recipesLikesPost
 * Summary: Incarca numarul de like-uri
 * Notes: 

 */
$app->POST('/BideniaAlexandru/Prop/1.0.0/recipes_Likes', function($request, $response, $args) {
            
            
            
            $body = $request->getParsedBody();
            $response->write('How about implementing recipesLikesPost as a POST method ?');
            return $response;
            });


/**
 * GET getRecipe
 * Summary: returneaza toate retetele unui user dupa idUser
 * Notes: 

 */
$app->GET('/BideniaAlexandru/Prop/1.0.0/recipes/{idUser}', function($request, $response, $args) {
            
            
            
            
            $response->write('How about implementing getRecipe as a GET method ?');
            return $response;
            });


/**
 * GET getRecipeAll
 * Summary: returneaza toate retetele
 * Notes: 

 */
$app->GET('/BideniaAlexandru/Prop/1.0.0/recipes_All', function($request, $response, $args) {
            
            
            
            
            $response->write('How about implementing getRecipeAll as a GET method ?');
            return $response;
            });


/**
 * POST postPassPost
 * Summary: Inregistreaza un utilizator nou
 * Notes: 

 */
$app->POST('/BideniaAlexandru/Prop/1.0.0/Post_Pass', function($request, $response, $args) {
            
            
            
            $body = $request->getParsedBody();
            $response->write('How about implementing postPassPost as a POST method ?');
            return $response;
            });


/**
 * POST postUserPost
 * Summary: Inregistreaza un utilizator nou
 * Notes: 

 */
$app->POST('/BideniaAlexandru/Prop/1.0.0/Post_User', function($request, $response, $args) {
            
            
            
            $body = $request->getParsedBody();
            $response->write('How about implementing postUserPost as a POST method ?');
            return $response;
            });



$app->run();
